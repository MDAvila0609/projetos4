# Projeto Web III
Projeto didático de um sistema para Pet Shop.

- Padrão MVC - Model/ View/ Controller
- Controle de sessão: controle de acesso por meio de autenticação
- Conexão com banco de dados MySql
