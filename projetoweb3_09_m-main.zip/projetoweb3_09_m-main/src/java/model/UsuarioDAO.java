package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class UsuarioDAO {
    private static Connection conn;
    
    public UsuarioDAO() throws SQLException, ClassNotFoundException {
        conn = MyConnection.getConnection();
    }
    
    //Iniciando métodos do CRUD
    //SELECT (READ)
    public ArrayList<Usuario> listUsuario() throws SQLException {
        //Criar lista vazia
        ArrayList<Usuario> list = new ArrayList<>();
        
        //Query SQL
        String query = "SELECT * FROM usuario";
        
        //Preparando a query para lançar no banco de dados
        PreparedStatement prep = conn.prepareStatement(query);
        
        //Recebendo o resultado da query na variável result
        //da classe ResultSet
        ResultSet result = prep.executeQuery();
        
        //Enqunto houverem resultados, executa a operação
        while(result.next()) {
            //Objeto vazio de Proprietario
            Usuario usuario = new Usuario();
            
            //Inserindo atributos neste objeto por meio dos setters
            usuario.setIdUsuario(result.getInt("id_usuario"));
            usuario.setNome(result.getString("nome"));
            usuario.setData(result.getString("data"));
            usuario.setCpf(result.getString("cpf"));
            usuario.setTelefone(result.getString("telefone"));
            usuario.setCep(result.getString("cep"));
            usuario.setCidade(result.getString("cidade"));
            usuario.setBairro(result.getString("bairro"));
            usuario.setRua(result.getString("rua"));
            usuario.setNumerocasa(result.getString("numerocasa"));
            usuario.setComplemento(result.getString("complemento"));
            
            //Adicionando objeto preenchido na lista
            list.add(usuario);
        }
        
        //Retornando a lista com todos os registros do BD
        return list;
    }
    
    
    //Insert (CREATE)
    public void insertUsuario(Usuario pro) throws SQLException {
        //Criar a query para inserção
        String query = "INSERT INTO usuario(nome, data, cpf, cep, cidade, bairro, rua, numerocasa, complemento)"
                + "VALUES(?,?,?,?,?,?)";
        
        //Pegar os atributos recebidos do objeto Proprietario
        //e lançar na query
        try ( //Preparando a query para lançar no BD
                PreparedStatement prep = conn.prepareStatement(query)) {
            //Pegar os atributos recebidos do objeto Proprietario
            //e lançar na query
            prep.setString(1, pro.getNome());
            prep.setString(1, pro.getData());
            prep.setString(2, pro.getCpf());
            prep.setString(3, pro.getTelefone());
            prep.setString(5, pro.getCep());
            prep.setString(6, pro.getCidade());
            prep.setString(7, pro.getBairro());
            prep.setString(8, pro.getRua());
            prep.setString(9, pro.getNumerocasa());
            prep.setString(10, pro.getComplemento());
            
            
            
            //Lnaçar a query pronta para o BD
            prep.execute();
        }
    }
    
    
    //DELETE
    public void deleteUsuario(int i) throws SQLException {
        String query = "DELETE FROM usuario "
                + "WHERE id_usuario = " + i;
        
        try (PreparedStatement prep = conn.prepareStatement(query)) {
            prep.execute();
        }
    }
    
    
    //LIST BY ID (Selecionar apenas um registro)
    public Usuario listById(int id) throws SQLException {
        Usuario p = new Usuario();
        
        String sql = "SELECT * FROM usuario "
                + "WHERE id_usuario = " + id;
        
        PreparedStatement prep = conn.prepareStatement(sql);
        ResultSet result = prep.executeQuery();
        
        if(result.next()) {
            p.setIdUsuario(result.getInt("id_usuario"));
            p.setNome(result.getString("nome"));
            p.setData(result.getString("data"));
            p.setCpf(result.getString("cpf"));
            p.setTelefone(result.getString("telefone"));
            p.setCep(result.getString("cep"));
            p.setCidade(result.getString("cidade"));
            p.setBairro(result.getString("bairro"));
            p.setRua(result.getString("rua"));
            p.setNumerocasa(result.getString("numerocasa"));
            p.setComplemento(result.getString("complemento"));
        }
        
        return p;
    }
    
    
    //UPDATE
    public void updateUsuario(Usuario p) throws SQLException {
        String sql = "UPDATE usuario SET nome = ?,"
                + "data = ?, cpf = ? "
                + "telefone = ?, cep = ?, cidade = ?,"
                + "bairro = ?, rua = ? "
                + "numerocasa = ?, complemento = ? "
                + "WHERE id_usuario = ?";
        
        try (PreparedStatement prep = conn.prepareStatement(sql)) {
            prep.setString(1, p.getNome());
            prep.setString(2, p.getData());
            prep.setString(2, p.getCpf());
            prep.setString(3, p.getTelefone());
            prep.setString(5, p.getCep());
            prep.setString(6, p.getCidade());
            prep.setString(7, p.getBairro());
            prep.setString(4, p.getRua());
            prep.setString(4, p.getNumerocasa());
            prep.setString(4, p.getComplemento());
            prep.setInt(7, p.getIdUsuario());
            
            prep.execute();
        }
    }
}
