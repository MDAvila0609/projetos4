package model;  
import java.sql.DriverManager;
import com.sun.jdi.connect.spi.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.ResultSet;



public class Conexao {
    private final String driver = "com.mysql.cj.jdbc.Driver";
    private final String servidor = "jdbc:mysql://localhost/lista1";
    private final String usuario = "root";
    private final String senha = "";
    private java.sql.Connection conectar (){
    try{
        Class.forName(driver);
        return DriverManager.getConnection(servidor, usuario, senha);
    }catch(ClassNotFoundException | SQLException ex){
        System.err.println(ex);
        return null;
    }
    }
   public ArrayList<Pessoa> pessoabd() throws SQLException{
       ArrayList<Pessoa> arrayPessoa = new ArrayList<>();
       try{
           ResultSet listapessoas = conectar().createStatement().executeQuery("select * from tbpessoa");
           while(listaPessoas.next())
               arrayPessoa.add(new Pessoa(listaPessoas.getInt("id"),
                       listaPessoas.getString("nome"),
                       listaPessoas.getString("data"),
                       listaPessoas.getString("cpf"),
                       listaPessoas.getString("telefone"),
                       listaPessoas.getString("cep"),
                       listaPessoas.getString("cidade"),
                       listaPessoas.getString("estado"),
                       listaPessoas.getString("bairro"),
                       listaPessoas.getString("rua"),
                       listaPessoas.getInt("nc"),
                       listaPessoas.getString("complemento");
             }catch(SQLException ex){
                 System.out.println(ex);
             }
       return arrayPessoa;
   }
   
}
